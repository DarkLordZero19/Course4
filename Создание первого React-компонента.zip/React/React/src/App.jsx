import React from 'react';
import BusinessCard from './BusinessCard.jsx';
import './index.css'

function App() {
  return (
    <div>
      <h1>Мое первое React-приложение</h1>
      <BusinessCard />
      <BusinessCard />
      <BusinessCard />
    </div>
  )
}

export default App;
